package app;

import java.util.List;

public interface Filter {

  List<Club> filter(List<Club> clubs);
}
