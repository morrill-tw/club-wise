This Application was built using Java Swing and the JDBC SQL connector. Make sure you have the connector
downloaded and installed into the project module.

You may need to change the address of the dump as well as other related url. Check the connection that
your local host is on and update accordingly! You can find this important link in line 20 of
our ClubWiseApp in the app directory. when prompted, put your own username (usually root) and whatever
password you have (if nothing put nothing). Then you should be able to see all of our data and interact
with our application!

If you need more assistance, follow the directions posted on the class Canvas for setting up a java connection
and connecting it to the project!